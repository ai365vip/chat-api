package common

var UsingSQLite = false
var UsingPostgreSQL = false

var SQLitePath = "one-api.db"
